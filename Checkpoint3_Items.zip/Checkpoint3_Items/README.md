# Checkpoint 3

## Getting Started
Simply type `npm install` in the terminal to install all the required packages and `npm run dev` to launch the app.

## About
This app is created as part of the third portion of the semester long project for the course CSE111 - Databases at UC Merced.